<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_583cbfa38b4d296b887eb982f2f1f211'] = 'Delete Orders Free';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_0ec4a7eb660632be2737b71f485d7614'] = 'Este módulo es el mejor módulo para suprimir órdenes. Esta versión es gratuita. Desarrollado por MyPresta.eu';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_37506cd68340dde4ffa3feb541a1134f'] = 'orgullosamente desarrollado por';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_a8ca510c1cce9f392b464b11e3180ed0'] = 'Llenar formulario con pedido ID correcto y elimínelo.';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_b64930ed2e8e35f40495c56bc25b8ebb'] = 'pedido ID';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_d1268a2df5471a7b5c7b7a2a22b8cee2'] = '¿Está seguro que desea eliminar:';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_d1a181a580a58434c409db7240b9440a'] = 'pedido?';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_b4659b504f9f4b7a551937d3f254df8d'] = 'Orden eliminado';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_01f40132137cf055c7f0c470ab4612e8'] = 'Algo malo....';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_c5aa7ae032a567ddec745fcd0cb188e7'] = 'Orden con esta identificación no existe';
