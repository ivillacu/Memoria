<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_583cbfa38b4d296b887eb982f2f1f211'] = 'Delete Orders Free';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_0ec4a7eb660632be2737b71f485d7614'] = 'Dieses Modul ist das beste Modul zum Löschen Bestellung. Diese Version ist kostenlos. Entwickelt von MyPresta.eu';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_37506cd68340dde4ffa3feb541a1134f'] = 'Stolz entwickelt von';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_a8ca510c1cce9f392b464b11e3180ed0'] = 'Füllen Sie Formular mit korrekten Bestellung ID und löschen.';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_b64930ed2e8e35f40495c56bc25b8ebb'] = 'Bestellung ID';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_d1268a2df5471a7b5c7b7a2a22b8cee2'] = 'Sind Sie sicher, dass Sie löschen möchten';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_d1a181a580a58434c409db7240b9440a'] = 'Bestellung?';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_b4659b504f9f4b7a551937d3f254df8d'] = 'Auftrag gelöscht.';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_01f40132137cf055c7f0c470ab4612e8'] = 'etwas falsch...';
$_MODULE['<{deleteordersfree}prestashop>deleteordersfree_c5aa7ae032a567ddec745fcd0cb188e7'] = 'Um mit dieser ID existiert nicht';
